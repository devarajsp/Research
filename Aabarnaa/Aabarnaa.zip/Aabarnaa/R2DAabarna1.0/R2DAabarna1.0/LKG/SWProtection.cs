
using System;
using System.Text;
using System.IO;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Windows.Forms;
using System.Management;
using System.Security.Cryptography;
using Microsoft.Win32;    

namespace LKG
{
	/// <summary>
	/// Summary description for SWProtection.
	/// </summary>
	public class SWProtection
	{

		private bool showError = false;
		/// <summary>
		/// A property to show or hide error messages 
		/// (default = false)
		/// </summary>
		public bool ShowError
		{
			get { return showError; }
			set	{ showError = value; }
		}

		private string subKey = "SOFTWARE\\II09A1" ;
		private string licKey = "ALK";
		/// <summary>
		/// A property to set the SubKey value
		/// (default = "SOFTWARE\\" + Application.ProductName.ToUpper())
		/// </summary>
		public string SubKey
		{
			get { return subKey; }
			set	{ subKey = value; }
		}

		private RegistryKey baseRegistryKey = Registry.LocalMachine;
		/// <summary>
		/// A property to set the BaseRegistryKey value.
		/// (default = Registry.LocalMachine)
		/// </summary>
		public RegistryKey BaseRegistryKey
		{
			get { return baseRegistryKey; }
			set	{ baseRegistryKey = value; }
		}

		public SWProtection()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public bool IsValidCopy()
		{
			string lic = this.Read(licKey);
			string pKey = "", lKey = "";
			bool validKey = false;

			if ( lic != null ) //License exists, check whether it is valid
			{
				pKey = GetRandomSysInfo();
				lKey = Glk(pKey);
				if ( lKey.Equals(lic) )
				{
					validKey = true;
				}
				else
				{
					validKey = false;
				}
			}
			else
			{
				validKey = false;
			}

			return validKey;
		}

		public bool CheckLic(string lic)
		{
			string pKey = "", lKey = "";
			bool validKey = false;

			if ( lic != null ) //License exists, check whether it is valid
			{
				pKey = GetRandomSysInfo();
				lKey = Glk(pKey);
				if ( lKey.Equals(lic) )
				{
					validKey = true;
				}
				else
				{
					validKey = false;
				}
			}
			else
			{
				validKey = false;
			}

			return validKey;
		}
		public bool SaveLic(string lic)
		{
			this.Write(licKey, lic);
			return true;
		}

		public string GetRandomSysInfo()
		{
			string nl = "\n";
			string info = "";
			info += this.GetAccount() + nl;
			info += this.GetBIOScaption()+ nl;
			info += this.GetBIOSmaker()+ nl;
			info += this.GetBIOSserNo()+ nl;
			info += this.GetBoardMaker()+ nl;
			info +=	this.GetBoardSerNo()+ nl;
			
			string hashString = ComputeHash(ObjectToByteArray(info));
			return hashString;
		}

		public string Read(string KeyName)
		{
			// Opening the registry key
			RegistryKey rk = baseRegistryKey ;
			// Open a subKey as read-only
			RegistryKey sk1 = rk.OpenSubKey(subKey);
			// If the RegistrySubKey doesn't exist -> (null)
			if ( sk1 == null )
			{
				return null;
			}
			else
			{
				try 
				{
					// If the RegistryKey exists I get its value
					// or null is returned.
					return (string)sk1.GetValue(KeyName.ToUpper());
				}
				catch (Exception e)
				{
					// AAAAAAAAAAARGH, an error!
					ShowErrorMessage(e, "Reading registry " + KeyName.ToUpper());
					return null;
				}
			}
		}

		
		private void ShowErrorMessage(Exception e, string Title)
		{
			if (showError == true)
				MessageBox.Show(e.Message,
					Title
					,MessageBoxButtons.OK
					,MessageBoxIcon.Error);
		}


		public bool Write(string KeyName, object Value)
		{
			try
			{
				// Setting
				RegistryKey rk = baseRegistryKey ;
				// I have to use CreateSubKey 
				// (create or open it if already exits), 
				// 'cause OpenSubKey open a subKey as read-only
				RegistryKey sk1 = rk.CreateSubKey(subKey);
				// Save the value
				sk1.SetValue(KeyName.ToUpper(), Value);

				return true;
			}
			catch (Exception e)
			{
				// AAAAAAAAAAARGH, an error!
				ShowErrorMessage(e, "Writing registry " + KeyName.ToUpper());
				return false;
			}
		}


		public bool DeleteKey(string KeyName)
		{
			try
			{
				// Setting
				RegistryKey rk = baseRegistryKey ;
				RegistryKey sk1 = rk.CreateSubKey(subKey);
				// If the RegistrySubKey doesn't exists -> (true)
				if ( sk1 == null )
					return true;
				else
					sk1.DeleteValue(KeyName);

				return true;
			}
			catch (Exception e)
			{
				// AAAAAAAAAAARGH, an error!
				ShowErrorMessage(e, "Deleting SubKey " + subKey);
				return false;
			}
		}


		public bool DeleteSubKeyTree()
		{
			try
			{
				// Setting
				RegistryKey rk = baseRegistryKey ;
				RegistryKey sk1 = rk.OpenSubKey(subKey);
				// If the RegistryKey exists, I delete it
				if ( sk1 != null )
					rk.DeleteSubKeyTree(subKey);

				return true;
			}
			catch (Exception e)
			{
				// AAAAAAAAAAARGH, an error!
				ShowErrorMessage(e, "Deleting SubKey " + subKey);
				return false;
			}
		}
		public int SubKeyCount()
		{
			try
			{
				// Setting
				RegistryKey rk = baseRegistryKey ;
				RegistryKey sk1 = rk.OpenSubKey(subKey);
				// If the RegistryKey exists...
				if ( sk1 != null )
					return sk1.SubKeyCount;
				else
					return 0; 
			}
			catch (Exception e)
			{
				// AAAAAAAAAAARGH, an error!
				ShowErrorMessage(e, "Retriving subkeys of " + subKey);
				return 0;
			}
		}
		

		public int ValueCount()
		{
			try
			{
				// Setting
				RegistryKey rk = baseRegistryKey ;
				RegistryKey sk1 = rk.OpenSubKey(subKey);
				// If the RegistryKey exists...
				if ( sk1 != null )
					return sk1.ValueCount;
				else
					return 0; 
			}
			catch (Exception e)
			{
				// AAAAAAAAAAARGH, an error!
				ShowErrorMessage(e, "Retriving keys of " + subKey);
				return 0;
			}
		}
		public string Glk(string pubKey)
		{
			string lk = "";
			for (int i=0;i<6;i++)
			{
				lk+=pubKey + this.GetSecretWord();
			}
			return ComputeHash(ObjectToByteArray(lk));
		}

		private string ComputeHash(byte[] objectAsBytes)
		{
			MD5 md5 = new MD5CryptoServiceProvider();
			try
			{
				byte[] result = md5.ComputeHash(objectAsBytes);

				// Build the final string by converting each byte
				// into hex and appending it to a StringBuilder
				StringBuilder sb = new StringBuilder();
				for (int i = 0; i < result.Length; i++)
				{
					sb.Append(result[i].ToString("X2"));
				}

				// And return it
				return sb.ToString();
			}
			catch (ArgumentNullException ane)
			{
				//If something occurred during serialization, 
				//this method is called with a null argument. 
				Console.WriteLine("Hash has not been generated.");
				return null;
			}
		}
		private readonly Object locker = new Object();

		private byte[] ObjectToByteArray(Object objectToSerialize)
		{
			MemoryStream fs = new MemoryStream();
			BinaryFormatter formatter = new BinaryFormatter();
			try
			{
				//Here's the core functionality! One Line!
				//To be thread-safe we lock the object
				lock (locker)
				{
					formatter.Serialize(fs, objectToSerialize);
				}
				return fs.ToArray();
			}
			catch (SerializationException se)
			{
				Console.WriteLine("Error occurred during serialization. Message: " +
					se.Message);
				return null;
			}
			finally
			{
				fs.Close();
			}
		}

		public string GetSecretWord()
		{
			return "Living with Good Courage, Good Health, Good Happiness and Be Together with the GOD is our motive";
		}
		// WMI Calls


		public string GetHardDisks()
		{
			ManagementObjectSearcher searcher = new
				ManagementObjectSearcher("root\\CIMV2", "SELECT * FROM Win32_LogicalDisk");

			StringBuilder sb = new StringBuilder();

			foreach (ManagementObject wmi in searcher.Get())
			{
				try
				{
					sb.Append("Drive Device ID: " + wmi.GetPropertyValue("DeviceID").ToString() + 
						Environment.NewLine);
					sb.Append("Caption: " + wmi.GetPropertyValue("Caption").ToString() + 
						Environment.NewLine);
					sb.Append("Volume Serial Number: " + 
						wmi.GetPropertyValue("VolumeSerialNumber").ToString() + Environment.NewLine);
					sb.Append("Free Space: " 
						+ wmi.GetPropertyValue("FreeSpace").ToString() + " bytes free" + 
						Environment.NewLine + Environment.NewLine);
				}
				catch 
				{ 
					return sb.ToString(); 
				}
			}
			return sb.ToString();
		}



		public string GetBoardMaker()
		{
			ManagementObjectSearcher searcher = new
				ManagementObjectSearcher("root\\CIMV2", "SELECT * FROM Win32_BaseBoard");

			foreach (ManagementObject wmi in searcher.Get())
			{
				try
				{
					return Environment.NewLine + "Board Maker: " + wmi.GetPropertyValue("Manufacturer").ToString();
				}
				catch {   }
			}
			return "Board Maker: Unknown";
		}


		public string GetBoardSerNo()
		{
			ManagementObjectSearcher searcher = new
				ManagementObjectSearcher("root\\CIMV2", "SELECT * FROM Win32_BaseBoard");

			foreach (ManagementObject wmi in searcher.Get())
			{
				try
				{
					return "Serial Number: " + wmi.GetPropertyValue("SerialNumber").ToString();
				}
				catch { }
			}
			return "Serial Number: Unknown";
		}


		public string GetBoardProductId()
		{
			ManagementObjectSearcher searcher = new
				ManagementObjectSearcher("root\\CIMV2", "SELECT * FROM Win32_BaseBoard");

			foreach (ManagementObject wmi in searcher.Get())
			{
				try
				{
					return "Product: " + wmi.GetPropertyValue("Product").ToString();
				}
				catch { }
			}
			return "Product: Unknown";
		}


		public string GetCacheBlockSize()
		{
			ManagementObjectSearcher searcher = new
				ManagementObjectSearcher("root\\CIMV2", "SELECT * FROM Win32_CacheMemory");

			foreach (ManagementObject wmi in searcher.Get())
			{
				try
				{
					return "Cache Block Size: " + wmi.GetPropertyValue("BlockSize").ToString();
				}
				catch { }
			}
			return "Cache Block Size: Unknown";
		}


		public string GetCacheType()
		{
			ManagementObjectSearcher searcher = new
				ManagementObjectSearcher("root\\CIMV2", "SELECT * FROM Win32_CacheMemory");

			foreach (ManagementObject wmi in searcher.Get())
			{
				try
				{
					return "Cache Type: " + wmi.GetPropertyValue("CacheType").ToString();
				}
				catch { }
			}
			return "Cache Type: Unknown";
		}


		public string GetCacheMaxSize()
		{
			ManagementObjectSearcher searcher = new
				ManagementObjectSearcher("root\\CIMV2", "SELECT * FROM Win32_CacheMemory");

			foreach (ManagementObject wmi in searcher.Get())
			{
				try
				{
					return "Max Cache Size: " + wmi.GetPropertyValue("MaxCacheSize").ToString();
				}
				catch { }
			}
			return "Max Cache Size: Unknown";
		}


		public string GetCdRomDrive()
		{
			ManagementObjectSearcher searcher = new
				ManagementObjectSearcher("root\\CIMV2", "SELECT * FROM Win32_CDROMDrive");

			foreach (ManagementObject wmi in searcher.Get())
			{
				try
				{
					return "CD ROM Drive Letter: " + wmi.GetPropertyValue("Drive").ToString();
				}
				catch { }
			}
			return "CD ROM Drive Letter: Unknown";
		}


		public string GetAccount()
		{
			ManagementObjectSearcher searcher = new
				ManagementObjectSearcher("root\\CIMV2", "SELECT * FROM Win32_UserAccount");

			foreach (ManagementObject wmi in searcher.Get())
			{
				try
				{
					return "User Account Name: " + wmi.GetPropertyValue("Name").ToString();
				}
				catch { }
			}
			return "User Account Name: Unknown";
		}


		//Win32_BIOS
		public string GetBIOScaption()
		{
			ManagementObjectSearcher searcher = new
				ManagementObjectSearcher("root\\CIMV2", "SELECT * FROM Win32_BIOS");

			foreach (ManagementObject wmi in searcher.Get())
			{
				try
				{
					return "BIOS Caption: " + wmi.GetPropertyValue("Caption").ToString();
				}
				catch { }
			}
			return "BIOS Caption: Unknown";
		}

		public string GetBIOSmaker()
		{
			ManagementObjectSearcher searcher = new
				ManagementObjectSearcher("root\\CIMV2", "SELECT * FROM Win32_BIOS");

			foreach (ManagementObject wmi in searcher.Get())
			{
				try
				{
					return "BIOS Maker: " + wmi.GetPropertyValue("Manufacturer").ToString();
				}
				catch { }
			}
			return "BIOS Maker: Unknown";
		}

		public string GetBIOSserNo()
		{
			ManagementObjectSearcher searcher = new
				ManagementObjectSearcher("root\\CIMV2", "SELECT * FROM Win32_BIOS");

			foreach (ManagementObject wmi in searcher.Get())
			{
				try
				{
					return "BIOS Serial Number: " + wmi.GetPropertyValue("SerialNumber").ToString();
				}
				catch { }
			}
			return "BIOS Serial Number: Unknown";
		}


		public string GetWinIconSpace()
		{
			ManagementObjectSearcher searcher = new
				ManagementObjectSearcher("root\\CIMV2", "SELECT * FROM Win32_Desktop");

			foreach (ManagementObject wmi in searcher.Get())
			{
				try
				{
					return "Desktop Icon Spacing: " + wmi.GetPropertyValue("IconSpacing").ToString();
				}
				catch { }
			}
			return "Desktop Icon Spacing: Unknown";
		}


		public string GetWinCursorBlinkRate()
		{
			ManagementObjectSearcher searcher = new
				ManagementObjectSearcher("root\\CIMV2", "SELECT * FROM Win32_Desktop");

			foreach (ManagementObject wmi in searcher.Get())
			{
				try
				{
					return "Cursor Blink Rate: " + wmi.GetPropertyValue("CursorBlinkRate").ToString();
				}
				catch { }
			}
			return "Cursor Blink Rate: Unknown";
		}


		public string GetWinScreenSaverActive()
		{
			ManagementObjectSearcher searcher = new
				ManagementObjectSearcher("root\\CIMV2", "SELECT * FROM Win32_Desktop");

			foreach (ManagementObject wmi in searcher.Get())
			{
				try
				{
					return "Screen Saver Active: " + wmi.GetPropertyValue("ScreenSaverActive").ToString();
				}
				catch { }
			}
			return "Screen Saver Active: Unknown";
		}

		public string GetWinCoolSwitch()
		{
			ManagementObjectSearcher searcher = new
				ManagementObjectSearcher("root\\CIMV2", "SELECT * FROM Win32_Desktop");

			foreach (ManagementObject wmi in searcher.Get())
			{
				try
				{
					return "CoolSwitch: " + wmi.GetPropertyValue("CoolSwitch").ToString();
				}
				catch { }
			}
			return "CoolSwitch: Unknown";
		}

	
	}
}
