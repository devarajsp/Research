using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Vastra
{
	/// <summary>
	/// Summary description for frmSWProtection.
	/// </summary>
	public class frmSWProtection : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Button btnRegister;
		private System.Windows.Forms.Button btnExit;
		private System.Windows.Forms.TextBox txtLicKey;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private System.Windows.Forms.TextBox lblPkey;
		private frmMain parentForm = null;

		public frmSWProtection(frmMain pf)
		{
			parentForm = pf;
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.txtLicKey = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.btnRegister = new System.Windows.Forms.Button();
			this.btnExit = new System.Windows.Forms.Button();
			this.lblPkey = new System.Windows.Forms.TextBox();
			this.SuspendLayout();
			// 
			// txtLicKey
			// 
			this.txtLicKey.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.txtLicKey.Location = new System.Drawing.Point(24, 160);
			this.txtLicKey.Name = "txtLicKey";
			this.txtLicKey.Size = new System.Drawing.Size(520, 35);
			this.txtLicKey.TabIndex = 0;
			this.txtLicKey.Text = "";
			// 
			// label2
			// 
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label2.Location = new System.Drawing.Point(24, 40);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(536, 24);
			this.label2.TabIndex = 2;
			this.label2.Text = "Copy the below Public Key and Give it to ItsInit to get the \'License Key\'";
			// 
			// label3
			// 
			this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label3.Location = new System.Drawing.Point(24, 136);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(536, 24);
			this.label3.TabIndex = 3;
			this.label3.Text = "Enter the License Key";
			// 
			// btnRegister
			// 
			this.btnRegister.Location = new System.Drawing.Point(96, 208);
			this.btnRegister.Name = "btnRegister";
			this.btnRegister.Size = new System.Drawing.Size(128, 40);
			this.btnRegister.TabIndex = 4;
			this.btnRegister.Text = "Register";
			this.btnRegister.Click += new System.EventHandler(this.btnRegister_Click);
			// 
			// btnExit
			// 
			this.btnExit.Location = new System.Drawing.Point(296, 208);
			this.btnExit.Name = "btnExit";
			this.btnExit.Size = new System.Drawing.Size(136, 40);
			this.btnExit.TabIndex = 5;
			this.btnExit.Text = "Exit";
			this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
			// 
			// lblPkey
			// 
			this.lblPkey.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblPkey.Location = new System.Drawing.Point(24, 72);
			this.lblPkey.Name = "lblPkey";
			this.lblPkey.ReadOnly = true;
			this.lblPkey.Size = new System.Drawing.Size(528, 35);
			this.lblPkey.TabIndex = 6;
			this.lblPkey.Text = "";
			// 
			// frmSWProtection
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(592, 272);
			this.Controls.Add(this.lblPkey);
			this.Controls.Add(this.btnExit);
			this.Controls.Add(this.btnRegister);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.txtLicKey);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "frmSWProtection";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "frmSWProtection";
			this.Load += new System.EventHandler(this.frmSWProtection_Load);
			this.ResumeLayout(false);

		}
		#endregion

		private void btnRegister_Click(object sender, System.EventArgs e)
		{
			SWProtection swp = new SWProtection();
			string lKey = txtLicKey.Text.Trim();

			if ( swp.CheckLic(lKey) )
			{
				swp.SaveLic(lKey);
				this.parentForm.showQuickView();
			}
			else
			{
				MessageBox.Show(this, "Sorry!! You have not entered a valid license key. Bye..");
				Application.Exit();
			}
		}

		private void frmSWProtection_Load(object sender, System.EventArgs e)
		{
			SWProtection swp = new SWProtection();
			string pKey = swp.GetRandomSysInfo();		
			lblPkey.Text = pKey;
		}

		private void btnExit_Click(object sender, System.EventArgs e)
		{
			Application.Exit();
		}
	}
}
