
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace Vastra
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class frmMain : System.Windows.Forms.Form
	{

		int defWidth	= 80;
		//int defHeight	= 200;
		int defTop		= 200;
		int defLeft		= 0;
		int shrinkWidth = 10;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmMain()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			// 
			// frmMain
			// 
			this.AutoScale = false;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.BackColor = System.Drawing.Color.Black;
			this.ClientSize = new System.Drawing.Size(80, 368);
			this.ControlBox = false;
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.ImeMode = System.Windows.Forms.ImeMode.AlphaFull;
			this.Name = "frmMain";
			this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
			this.Text = "Vastra..";
			this.TopMost = true;
			this.Click += new System.EventHandler(this.frmMain_Click);
			this.Load += new System.EventHandler(this.frmMain_Load);
			this.MouseEnter += new System.EventHandler(this.frmMain_MouseEnter);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{

			//Application.Run(new frmDressDetail(null));
			Application.Run(new frmMain());
			//Application.Run(new frmQuickView());
			//Application.Run(new frmWrapNcompare());
		}

		private void btnExit_Click(object sender, System.EventArgs e)
		{
			Application.Exit();
		}

		private void frmMain_Load(object sender, System.EventArgs e)
		{

			init();
		}
		
		private void init()
		{
			this.Width	= defWidth;
			//this.Height = defHeight;
			this.Top	= defTop;
			this.Left	= defLeft;
			this.Height = 1;this.Width = 1;
			if ( CanRun() )
			{
				showQuickView();
			}
			else
			{
				showSP();
			}
			//showHowAmI();
		}

		private bool CanRun()
		{
			SWProtection swp = new SWProtection();
			return swp.IsValidCopy();
		}

		public bool Shrink 
		{
			get 
			{
				if ( this.Width == shrinkWidth ) return true;
				else return false;
			}
			set
			{
				if ( value == true )
				{
					this.Width = shrinkWidth;
				}
				if ( value == false )
				{
					this.Width = defWidth;
				}	
			}
		}

		private void frmMain_Click(object sender, EventArgs e)
		{
			if ( this.Shrink == true )
				this.Shrink = false;
			else
				this.Shrink = true;
				
		}

		private void frmMain_MouseEnter(object sender, EventArgs e)
		{
			this.Shrink = false;
		}


		frmWrapNcompare wrapview = null;
		public void showWrapNcompare()
		{
			this.closeall();
			if ( wrapview == null )
			{
				wrapview = new frmWrapNcompare(this);
				wrapview.ShowDialog();
			}
		}

		public void closeWrapNcompare()
		{
			if ( wrapview != null )
			{
				wrapview.closeall();
				wrapview.Close();
				wrapview.Dispose();
				wrapview = null;
			}
		}


		frmQuickView qv = null;
		public void showQuickView()
		{
			this.closeall();
			string []dfiles = System.IO.Directory.GetDirectories("c:/aabarna/dress");

			if ( qv == null )
			{
				this.Hide();
				qv = new frmQuickView(this, dfiles);
				//qv.Show();
				qv.ShowDialog();
				
			}
		}	

		
		frmSWProtection sp = null;
		public void showSP()
		{
			this.closeall();
			if ( sp == null )
			{
				this.Hide();
				sp = new frmSWProtection(this);
				sp.ShowDialog();
				
			}
		}	

		public void closeSP()
		{
			if ( sp != null )
			{
				sp.Close();
				sp.Dispose();
				sp = null;
			}
		}

		public void closeall()
		{
			closeSP();
			closeQuickView();
			closeWrapNcompare();
			closeDressDetails();
			closeJewelStudio();
		}
	
		public void closeQuickView()
		{
			if ( qv != null )
			{
				qv.closeall();
				qv.Close();
				qv.Dispose();
				qv = null;
			}
		}
		

		//frmDressDetail dd = null;
		public void showDressDetails()
		{
//			this.closeall();
//			if ( dd == null )
//			{
//				dd = new frmDressDetail(this,"c:/aabarna/dress/dress1_");
//				dd.Show();
//			}
		}

		public void closeDressDetails()
		{
//			if ( dd != null )
//			{
//				dd.closeall();
//				dd.Close();
//				dd.Dispose();
//				dd = null;
//			}
		}

		frmJewelStudio js = null;
		public void showJewelStudio()
		{
			this.closeall();
			if ( js == null )
			{
				js = new frmJewelStudio(this,null);
				js.ShowDialog();
			}
		}

		public void closeJewelStudio()
		{
			if ( js != null )
			{
				js.closeall();
				js.Close();
				js.Dispose();
				js = null;
			}
		}

	}
}
