

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;


namespace Vastra
{
	/// <summary>
	/// Summary description for frmWrapNcompare.
	/// </summary>
	public class frmWrapNcompare : System.Windows.Forms.Form
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		private WebCamCapture WebCamCapture;
		private System.Windows.Forms.PictureBox []pbView;
		int viewcount = 2, curIndex = 0;

		public void init()
		{
			int t=50, l=25,g = 25, w, h;
			int t1, t2, l1, l2;
			this.pbView = new PictureBox[3];

			this.BackgroundImage = Image.FromFile("c:/aabarna/conf/bkg2_1024x768.jpg",false);

			w = 458;//(Screen.PrimaryScreen.Bounds.Width / viewcount) - 20;
			h = 680;//Screen.PrimaryScreen.Bounds.Height - 20;
			t1 = 45;
			t2 = 45;
			l1 = 40;
			l2 = 520;

			for (int i = 0; i < viewcount; i++)
			{
				this.pbView[i] = new PictureBox();
				this.pbView[i].BorderStyle = System.Windows.Forms.BorderStyle.None;
				//this.pbCloth[i].Location = new System.Drawing.Point(t, l);
				this.pbView[i].Top = t;
				this.pbView[i].Left = l+g;
				this.pbView[i].Name = "pbView"+i.ToString();
				this.pbView[i].Size = new System.Drawing.Size(w, h);
				this.pbView[i].SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
				this.pbView[i].TabIndex = 8;
				this.pbView[i].TabStop = true;
				this.pbView[i].Click +=new EventHandler(frmWrapNcompare_Click);
				this.pbView[i].DoubleClick +=new EventHandler(frmWrapNcompare_DoubleClick);

				this.Controls.Add(this.pbView[i]);					
				l += w;
			}
			this.KeyDown +=new KeyEventHandler(frmWrapNcompare_KeyDown);
			this.DoubleClick +=new EventHandler(frmWrapNcompare_DoubleClick);

			this.pbView[0].Top = t1;this.pbView[0].Left = l1;
			this.pbView[1].Top = t1;this.pbView[1].Left = l2;

			

			//init webcam3
			this.WebCamCapture = new WebCamCapture();
			this.WebCamCapture.CaptureHeight = h;
			this.WebCamCapture.CaptureWidth = w;
			// TODO: Code generation for 'this.WebCamCapture.FrameNumber' failed because of Exception 'Invalid Primitive Type: System.UInt64. Only CLS compliant primitive types can be used. Consider using CodeObjectCreateExpression.'.
			this.WebCamCapture.Location = new System.Drawing.Point(17, 17);
			this.WebCamCapture.Name = "WebCamCapture";
			this.WebCamCapture.Size = new System.Drawing.Size(w, h);
			this.WebCamCapture.TabIndex = 0;
			this.WebCamCapture.TimeToCapture_milliseconds = 10;
			this.WebCamCapture.ImageCaptured +=new Vastra.WebCamCapture.WebCamEventHandler(WebCamCapture_ImageCaptured);
			this.WebCamCapture.Start(0);

		}

		public void closeall()
		{
			if ( this.WebCamCapture != null )
			{
				this.WebCamCapture.Stop();
				this.WebCamCapture.Dispose();
				this.WebCamCapture = null;
			}
		}

		public frmMain mainForm = null;
		public frmWrapNcompare(frmMain mform)
		{
			mainForm = mform;
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			//this.mainForm = p;


			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}
		public void DefaultKeyAction(KeyEventArgs e)
		{
			if ( e.KeyCode == Keys.F5 
				||e.KeyCode == Keys.PageUp 
				||e.KeyCode == Keys.PageDown )
			{
				curIndex++; // Capture image
			}

			else if ( e.KeyCode == Keys.F2 )
			{
				this.mainForm.showJewelStudio();
			}
			else if ( e.KeyCode == Keys.F7 )
			{
				this.mainForm.showQuickView();
			}
			else if ( e.KeyCode == Keys.F8 )
			{
			}
			else if ( e.KeyCode == Keys.F9 )
			{
				this.mainForm.showDressDetails();
			}
			else if ( e.KeyCode == Keys.F10 )
			{
				Application.Exit();
			}
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			// 
			// frmWrapNcompare
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 273);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "frmWrapNcompare";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "frmWrapNcompare";
			this.TopMost = true;
			this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
			this.Load += new System.EventHandler(this.frmWrapNcompare_Load);

		}
		#endregion

		private void frmWrapNcompare_Click(object sender, EventArgs e)
		{
			curIndex++;
		}

		private void frmWrapNcompare_Load(object sender, System.EventArgs e)
		{
			init();
		}

		private void WebCamCapture_ImageCaptured(object source, WebcamEventArgs e)
		{

			if ( curIndex < viewcount )
			{
				this.pbView[curIndex].Image = (Image)e.WebCamImage.Clone();
			}
			else
			{
				//WebCamCapture.Stop();
				if ( curIndex == (viewcount + 1) )
				{

					for ( int i = 0; i < viewcount; i++)
					{
						this.pbView[i].Image.Save("c:/aabarna/temp/WrapNcompareImg"+i+".bmp", System.Drawing.Imaging.ImageFormat.Bmp);
						this.pbView[i].Image = null;
					}
					curIndex = 0;
				}
			}
		}

		private void frmWrapNcompare_KeyDown(object sender, KeyEventArgs e)
		{
			DefaultKeyAction(e);
		}

		private void frmWrapNcompare_DoubleClick(object sender, EventArgs e)
		{
			mainForm.showQuickView();
		}
	}
}
