using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Runtime.InteropServices;


namespace Vastra 
{
		/// <summary>
		/// Summary description for frmUserInfo.
		/// </summary>
		public class frmJewelStudio : System.Windows.Forms.Form
		{
			private System.Windows.Forms.PictureBox pbUserView;
			private System.Windows.Forms.Button btnReduceWidth;
			private System.Windows.Forms.GroupBox gbAjustment;
			private System.Windows.Forms.Button btnReduceHeight;
			private System.Windows.Forms.Button btnIncreaseHeight;
			private System.Windows.Forms.Button btnIncreaseWidth;
			private System.Windows.Forms.GroupBox gbBrowseDress;
			private System.Windows.Forms.Button btnPrevDress;
			private System.Windows.Forms.Button btnNextDress;
			private System.ComponentModel.IContainer components;

			private frmMain parentForm;
			bool pause = false;
			private System.Windows.Forms.Timer timer_Animation;
			private System.Windows.Forms.Button btnAnim;
			private System.Windows.Forms.PictureBox pbDetailsRight;
			private System.Windows.Forms.PictureBox pbDetailsLeft;
			private System.Windows.Forms.PictureBox pbShopLogo;
			private System.Windows.Forms.SaveFileDialog saveFileDialog1;
			public string [] files;

			[DllImport("user32.dll")]
			static extern int ShowCursor(bool bCurs);

			public frmJewelStudio()
			{
				files = System.IO.Directory.GetDirectories("c:/aabarna/dress");
				InitializeComponent();
				parentForm = null;
			}
			public frmJewelStudio(frmMain pForm, string []dresses)
			{
				//
				// Required for Windows Form Designer support
				//
				files = dresses;
				InitializeComponent();
				parentForm = pForm;
		

				//
				// TODO: Add any constructor code after InitializeComponent call
				//
			}

			/// <summary>
			/// Clean up any resources being used.
			/// </summary>
			protected override void Dispose( bool disposing )
			{
				if( disposing )
				{
					if(components != null)
					{
						components.Dispose();
					}
				}
				base.Dispose( disposing );
			}

			#region Windows Form Designer generated code
			/// <summary>
			/// Required method for Designer support - do not modify
			/// the contents of this method with the code editor.
			/// </summary>
			private void InitializeComponent()
			{
				this.components = new System.ComponentModel.Container();
				this.pbUserView = new System.Windows.Forms.PictureBox();
				this.gbAjustment = new System.Windows.Forms.GroupBox();
				this.btnReduceHeight = new System.Windows.Forms.Button();
				this.btnIncreaseHeight = new System.Windows.Forms.Button();
				this.btnIncreaseWidth = new System.Windows.Forms.Button();
				this.btnReduceWidth = new System.Windows.Forms.Button();
				this.gbBrowseDress = new System.Windows.Forms.GroupBox();
				this.btnNextDress = new System.Windows.Forms.Button();
				this.btnPrevDress = new System.Windows.Forms.Button();
				this.timer_Animation = new System.Windows.Forms.Timer(this.components);
				this.btnAnim = new System.Windows.Forms.Button();
				this.pbDetailsRight = new System.Windows.Forms.PictureBox();
				this.pbDetailsLeft = new System.Windows.Forms.PictureBox();
				this.pbShopLogo = new System.Windows.Forms.PictureBox();
				this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
				this.gbAjustment.SuspendLayout();
				this.gbBrowseDress.SuspendLayout();
				this.SuspendLayout();
				// 
				// pbUserView
				// 
				this.pbUserView.BackColor = System.Drawing.Color.White;
				this.pbUserView.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
				this.pbUserView.Location = new System.Drawing.Point(96, 88);
				this.pbUserView.Name = "pbUserView";
				this.pbUserView.Size = new System.Drawing.Size(96, 64);
				this.pbUserView.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
				this.pbUserView.TabIndex = 0;
				this.pbUserView.TabStop = false;
				this.pbUserView.DoubleClick += new System.EventHandler(this.pbUserView_DoubleClick);
				this.pbUserView.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pbUserView_MouseMove);
				this.pbUserView.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbUserView_MouseDown);
				// 
				// gbAjustment
				// 
				this.gbAjustment.Controls.Add(this.btnReduceHeight);
				this.gbAjustment.Controls.Add(this.btnIncreaseHeight);
				this.gbAjustment.Controls.Add(this.btnIncreaseWidth);
				this.gbAjustment.Controls.Add(this.btnReduceWidth);
				this.gbAjustment.Location = new System.Drawing.Point(336, 24);
				this.gbAjustment.Name = "gbAjustment";
				this.gbAjustment.Size = new System.Drawing.Size(184, 256);
				this.gbAjustment.TabIndex = 1;
				this.gbAjustment.TabStop = false;
				this.gbAjustment.Text = "Size Adjustment";
				this.gbAjustment.Visible = false;
				// 
				// btnReduceHeight
				// 
				this.btnReduceHeight.Location = new System.Drawing.Point(72, 152);
				this.btnReduceHeight.Name = "btnReduceHeight";
				this.btnReduceHeight.Size = new System.Drawing.Size(50, 50);
				this.btnReduceHeight.TabIndex = 3;
				this.btnReduceHeight.Text = "V";
				// 
				// btnIncreaseHeight
				// 
				this.btnIncreaseHeight.BackColor = System.Drawing.Color.White;
				this.btnIncreaseHeight.Location = new System.Drawing.Point(72, 56);
				this.btnIncreaseHeight.Name = "btnIncreaseHeight";
				this.btnIncreaseHeight.Size = new System.Drawing.Size(50, 50);
				this.btnIncreaseHeight.TabIndex = 2;
				this.btnIncreaseHeight.TabStop = false;
				this.btnIncreaseHeight.Text = "^";
				// 
				// btnIncreaseWidth
				// 
				this.btnIncreaseWidth.Location = new System.Drawing.Point(120, 104);
				this.btnIncreaseWidth.Name = "btnIncreaseWidth";
				this.btnIncreaseWidth.Size = new System.Drawing.Size(50, 50);
				this.btnIncreaseWidth.TabIndex = 1;
				this.btnIncreaseWidth.Text = ">>";
				// 
				// btnReduceWidth
				// 
				this.btnReduceWidth.Location = new System.Drawing.Point(24, 104);
				this.btnReduceWidth.Name = "btnReduceWidth";
				this.btnReduceWidth.Size = new System.Drawing.Size(50, 50);
				this.btnReduceWidth.TabIndex = 0;
				this.btnReduceWidth.Text = "<<";
				// 
				// gbBrowseDress
				// 
				this.gbBrowseDress.Controls.Add(this.btnNextDress);
				this.gbBrowseDress.Controls.Add(this.btnPrevDress);
				this.gbBrowseDress.Location = new System.Drawing.Point(336, 288);
				this.gbBrowseDress.Name = "gbBrowseDress";
				this.gbBrowseDress.Size = new System.Drawing.Size(184, 80);
				this.gbBrowseDress.TabIndex = 4;
				this.gbBrowseDress.TabStop = false;
				this.gbBrowseDress.Text = "Browse Dress";
				this.gbBrowseDress.Visible = false;
				// 
				// btnNextDress
				// 
				this.btnNextDress.Location = new System.Drawing.Point(112, 15);
				this.btnNextDress.Name = "btnNextDress";
				this.btnNextDress.Size = new System.Drawing.Size(50, 50);
				this.btnNextDress.TabIndex = 2;
				this.btnNextDress.Text = ">>";
				this.btnNextDress.Click += new System.EventHandler(this.btnNextDress_Click);
				// 
				// btnPrevDress
				// 
				this.btnPrevDress.Location = new System.Drawing.Point(16, 16);
				this.btnPrevDress.Name = "btnPrevDress";
				this.btnPrevDress.Size = new System.Drawing.Size(50, 50);
				this.btnPrevDress.TabIndex = 1;
				this.btnPrevDress.Text = "<<";
				this.btnPrevDress.Click += new System.EventHandler(this.btnPrevDress_Click);
				// 
				// timer_Animation
				// 
				this.timer_Animation.Interval = 5000;
				this.timer_Animation.Tick += new System.EventHandler(this.timer_Animation_Tick);
				// 
				// btnAnim
				// 
				this.btnAnim.Location = new System.Drawing.Point(432, 376);
				this.btnAnim.Name = "btnAnim";
				this.btnAnim.Size = new System.Drawing.Size(80, 64);
				this.btnAnim.TabIndex = 5;
				this.btnAnim.TabStop = false;
				this.btnAnim.Text = "Anim Stop/Start";
				this.btnAnim.Visible = false;
				this.btnAnim.Click += new System.EventHandler(this.btnAnim_Click);
				// 
				// pbDetailsRight
				// 
				this.pbDetailsRight.Location = new System.Drawing.Point(160, 184);
				this.pbDetailsRight.Name = "pbDetailsRight";
				this.pbDetailsRight.Size = new System.Drawing.Size(72, 56);
				this.pbDetailsRight.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
				this.pbDetailsRight.TabIndex = 6;
				this.pbDetailsRight.TabStop = false;
				this.pbDetailsRight.DoubleClick += new System.EventHandler(this.pbDetailsRight_DoubleClick);
				this.pbDetailsRight.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pbDetailsRight_MouseMove);
				this.pbDetailsRight.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbDetailsRight_MouseDown);
				// 
				// pbDetailsLeft
				// 
				this.pbDetailsLeft.Location = new System.Drawing.Point(72, 288);
				this.pbDetailsLeft.Name = "pbDetailsLeft";
				this.pbDetailsLeft.Size = new System.Drawing.Size(96, 72);
				this.pbDetailsLeft.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
				this.pbDetailsLeft.TabIndex = 7;
				this.pbDetailsLeft.TabStop = false;
				this.pbDetailsLeft.Visible = false;
				// 
				// pbShopLogo
				// 
				this.pbShopLogo.BackColor = System.Drawing.Color.Transparent;
				this.pbShopLogo.Location = new System.Drawing.Point(208, 40);
				this.pbShopLogo.Name = "pbShopLogo";
				this.pbShopLogo.Size = new System.Drawing.Size(104, 56);
				this.pbShopLogo.TabIndex = 8;
				this.pbShopLogo.TabStop = false;
				this.pbShopLogo.Visible = false;
				// 
				// frmQuickView
				// 
				this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
				this.BackColor = System.Drawing.Color.Violet;
				this.ClientSize = new System.Drawing.Size(592, 552);
				this.Controls.Add(this.pbShopLogo);
				this.Controls.Add(this.pbDetailsLeft);
				this.Controls.Add(this.pbDetailsRight);
				this.Controls.Add(this.btnAnim);
				this.Controls.Add(this.gbBrowseDress);
				this.Controls.Add(this.gbAjustment);
				this.Controls.Add(this.pbUserView);
				this.Cursor = System.Windows.Forms.Cursors.SizeAll;
				this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
				this.KeyPreview = true;
				this.Name = "frmQuickView";
				this.ShowInTaskbar = false;
				this.Text = "frmUserInfo";
				this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frmQuickView_KeyDown);
				this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.frmQuickView_MouseDown);
				this.Load += new System.EventHandler(this.frmUserInfo_Load);
				this.DoubleClick += new System.EventHandler(this.frmQuickView_DoubleClick);
				this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.frmQuickView_MouseMove);
				this.gbAjustment.ResumeLayout(false);
				this.gbBrowseDress.ResumeLayout(false);
				this.ResumeLayout(false);

			}
			#endregion

			private void frmUserInfo_Load(object sender, System.EventArgs e)
			{
				init();
			}

			int t=0, l=0, w, h;
			int t1=0, l1=0, w1, h1;
			int sh, sw;
			string bkg_file = "";
			int shop_logo_left = 0, shop_logo_top = 0;
			int shop_logo_height = 0, shop_logo_width = 0;
			string shop_logo_file = "";

			//Hardcoded values
			string conf_folder		= "c:/aabarna/conf";
			string temp_folder		= "c:/aabarna/temp";
			string file_seperator	= "/";
			string logo_file_name	= "shop_logo.gif";
			string bkg1_1024x768	= "bkg1_1024x768.jpg";
			string screen_resolution = "1024x768";
			string ext_bmp			= ".bmp";



			private WebCamCapture WebCamCapture;
			frmBody dress;

			public void init()
			{
				if ( screen_resolution.Equals("1024x768") )
				{
					h = 680;w = 575;
					t = 45; l = 45;
					h1 = 446;w1 = 296;
					t1 = 178; l1 = 672;
					sh = 750; sw = 1200;
					shop_logo_left = 0;shop_logo_top = 0;
					shop_logo_height = 0;shop_logo_width = 0;
					shop_logo_file = conf_folder + file_seperator + logo_file_name;
					bkg_file = conf_folder + file_seperator + bkg1_1024x768;
				}
				else if ( screen_resolution.Equals("800x600") )
				{
					h = 530;w = 450;
					t = 35; l = 35;
					h1 = 350;w1 = 230;
					t1 = 136; l1 = 526;
					sh = 750; sw = 1200;
					bkg_file = "c:/aabarna/conf/bkg1_800x600.jpg";
				}
				else if ( screen_resolution.Equals("1200x750"))
				{
					h = 662;w = 675;
					t = 45; l = 52;
					h1 = 437;w1 = 347;
					t1 = 173; l1 = 788;
					sh = 750; sw = 1200;
					bkg_file = "c:/aabarna/conf/bkg1_1200x750.jpg";
				}
				else if ( screen_resolution.Equals("1280x800"))
				{
					h = 705;w = 720;
					t = 50; l = 55;
					h1 = 465;w1 = 370;
					t1 = 185; l1 = 840;
					sh = 800; sw = 1280;
					bkg_file = "c:/aabarna/conf/bkg1.jpg";
				}		
			
				this.pbUserView.Height = h;	
				this.pbUserView.Width = w;
				this.pbUserView.Top = t;
				this.pbUserView.Left = l;//(Screen.PrimaryScreen.Bounds.Width - this.pbUserView.Width)/2;
				this.pbUserView.TabIndex = 8;
				//			this.pbUserView.Height = 800;
				//			this.pbUserView.Width = 600;
				//			this.pbUserView.Top = (Screen.PrimaryScreen.Bounds.Height - this.pbUserView.Height)/2;
				//			this.pbUserView.Left = (Screen.PrimaryScreen.Bounds.Width - this.pbUserView.Width)/2;

				this.Controls.Add(this.pbUserView);	
				this.Top = 0;
				this.Left = 0;

				this.gbAjustment.Left = 10; //this.Width - this.gbAjustment.Width;
				this.gbAjustment.Top = (this.Height - this.gbAjustment.Height)/2;

				this.gbBrowseDress.Left = 10; //this.Width - this.gbBrowseDress.Width;
				this.gbBrowseDress.Top = 0;

				this.btnAnim.Left = 0;
//				this.dress = new frmBody(this);
//			
//				dress.LoadImage("c:/aabarna/dress/dress1_", 130, 300);
//				dress.Width = (int) (dress.Width * 1);
//				dress.Height = (int)(dress.Height * 1);
//				dress.Left = this.pbUserView.Left + ( this.pbUserView.Width - dress.Width ) / 2;
//				dress.Top  = this.pbUserView.Top + this.pbUserView.Height - dress.Height ;
//				dress.Show();
			
				try
				{
					this.WebCamCapture = new WebCamCapture();
					this.WebCamCapture.CaptureHeight = h;
					this.WebCamCapture.CaptureWidth = w;
					this.WebCamCapture.Location = new System.Drawing.Point(17, 17);
					this.WebCamCapture.Name = "WebCamCapture";
					this.WebCamCapture.Size = new System.Drawing.Size(w, h);
					this.WebCamCapture.TabIndex = 0;
					this.WebCamCapture.TimeToCapture_milliseconds = 100;
					this.WebCamCapture.ImageCaptured +=new Vastra.WebCamCapture.WebCamEventHandler(WebCamCapture_ImageCaptured);
					this.WebCamCapture.Start(0); 
				}
				catch
				{
					this.pbUserView.Image = Image.FromFile("c:/aabarna/face/defHead.jpg", false);
				}
				//this.pbUserView.Image = Image.FromFile("c:/aabarna/face/defHead.jpg", false);//SPD BGFIX
				//Bitmap tbmp = new Bitmap(Bitmap.FromFile("c:/aabarna/face/defHead.jpg",false));
				Bitmap tbmp = new Bitmap(Bitmap.FromFile(@"C:\Aabarna\dress\dress1_\fair\test.jpg",false));
				Bitmap res = new Bitmap(tbmp.Width, tbmp.Height);
				
				//FaceDetection.DetectSkin(tbmp, ref res);
				//FaceDetection.DetectEdges(tbmp, ref res, tbmp.GetPixel(10,10), 30);
				FaceDetection.RemoveBackground(tbmp, ref res, tbmp.GetPixel(10,10), 40);
				//this.pbUserView.Height = (int)(tbmp.Height * 1);
				//this.pbUserView.Width = (int)(tbmp.Width * 1);
				//res.Save("c:/vastra/face/defHead_fd.bmp");			
				//this.pbUserView.Image = Image.FromFile("c:/vastra/face/defHead_fd.bmp", false);
				
				res.MakeTransparent(Color.White);
 				
				this.pbUserView.Image		= Image.FromHbitmap(res.GetHbitmap(Color.Transparent));
				this.Height					= Screen.PrimaryScreen.Bounds.Height;
				this.Width					= Screen.PrimaryScreen.Bounds.Width;

				this.pbUserView.Image.Save("c:/test.gif", System.Drawing.Imaging.ImageFormat.Gif);
				//ShowCursor(false);
				this.pbDetailsRight.Width	= w1;//(this.Width - this.pbUserView.Width) / 2;
				this.pbDetailsRight.Height	= h1;
				this.pbDetailsRight.Top		= t1;//this.pbUserView.Top;
				this.pbDetailsRight.Left	= l1;//840;//(this.pbUserView.Left + this.pbUserView.Width + gutter);
		
				this.pbDetailsLeft.Width	= this.pbDetailsRight.Width ;
				this.pbDetailsLeft.Height	= this.pbDetailsRight.Height/6;
				this.pbDetailsLeft.Top		= this.pbDetailsRight.Top + this.pbDetailsRight.Height;
				this.pbDetailsLeft.Left		= this.pbDetailsRight.Left;
				//this.pbDetailsLeft.Visible = true;
		
				this.BackgroundImage = Image.FromFile(bkg_file,false);

				//Making picbox as round corner;
				Rectangle r = new Rectangle(0, 0, this.pbUserView.Width, this.pbUserView.Height);
				System.Drawing.Drawing2D.GraphicsPath gp = new System.Drawing.Drawing2D.GraphicsPath();
				int d = 50;
				gp.AddArc(r.X, r.Y, d, d, 180, 90);
				gp.AddArc(r.X + r.Width - d, r.Y, d, d, 270, 90);
				gp.AddArc(r.X + r.Width - d, r.Y + r.Height - d, d, d, 0, 90);
				gp.AddArc(r.X, r.Y + r.Height - d, d, d, 90, 90);
				this.pbUserView.Region = new Region(gp);
			
				//Disable auto slideshow
				timer_Animation.Enabled = false;		
				nextdress();

				PlaceCursorInDefaultPosition();
			}
			//int gutter = 20;

			public void PlaceCursorInDefaultPosition()
			{
				//Cursor.Position = new Point(dress.Left, dress.Top - 10);
			}


			public void closeall()
			{
				if ( this.dress != null )
				{
					this.dress.Close();
					this.dress.Dispose();
					this.dress = null;
				}

				if ( this.WebCamCapture != null )
				{
					this.WebCamCapture.Stop();
					this.WebCamCapture.Dispose();
					this.WebCamCapture = null;
				}
			}


			bool captured = false;
			private void WebCamCapture_ImageCaptured(object source, WebcamEventArgs e)
			{
				try
				{
					if ( pause != true )
					{
						lock( this.pbUserView.Image)
						{
							if ( this.pbUserView.Image != null )
							{
								this.pbUserView.Image.Dispose(); 
								this.pbUserView.Image = null;
							}
							this.pbUserView.Image = (Image)e.WebCamImage.Clone();;						
						}
					}
					else
					{
						if ( captured == false )
						{
							this.pbUserView.Image.Save("c:/aabarna/temp/UserPic.bmp", System.Drawing.Imaging.ImageFormat.Bmp);
							captured = true;
						}
					}
				}
				catch
				{
					this.pbUserView.Image = Image.FromFile("c:/aabarna/face/defHead.jpg", false);
				}
			}

			int chunkSize = 10;
		
			private void stopCapture()
			{
			
				if ( this.pbUserView != null )
				{
					if ( pause == true ) 
					{
						pause = false;
						captured = false;
					}
					else
					{
						pause = true;
					}
				}
			}

			private void frmUserInfo_Click(object sender, EventArgs e)
			{
				stopCapture();
			}

			private void btnStopCapture_Click(object sender, System.EventArgs e)
			{
				stopCapture();
			}

			private void btnMoveLeft_Click(object sender, System.EventArgs e)
			{
				if ( dress != null )
					dress.Left -=  chunkSize;
			}

			private void btnMoveRight_Click(object sender, System.EventArgs e)
			{
				if ( dress != null )
					dress.Left +=  chunkSize;
			}

			private void btnMoveUp_Click(object sender, System.EventArgs e)
			{
				if ( dress != null )
					dress.Top -=  chunkSize;
			}

			private void btnMoveDown_Click(object sender, System.EventArgs e)
			{
				if ( dress != null )
					dress.Top +=  chunkSize;
				
			}
 
			MouseEventArgs prevE = null;

			int jewelNeckStart = 100, jewelNeckEnd = 275;
			public void DefaultMouseMoveEvent(MouseEventArgs e)
			{			
				int wChange, hChange;

			{
				if ( prevE == null )
					prevE = e;
				else
				{
					wChange = e.X - prevE.X;
					hChange = e.Y - prevE.Y;

					if ( dress != null )
					{
						//dress.increaseWidth(chunkSize * wChange, false);
						//dress.increaseHeight(chunkSize * hChange, false);
						if ( (dress.Top + hChange) < this.pbUserView.Height && (dress.Top + hChange) > 0 ) 
							dress.Top += (hChange);
						else
							PlaceCursorInDefaultPosition();


						if ( (dress.Left + wChange + jewelNeckEnd) < (this.pbUserView.Left + this.pbUserView.Width) && 
							(dress.Left + wChange + jewelNeckStart) > this.pbUserView.Left )
							dress.Left += (wChange);
						else
							PlaceCursorInDefaultPosition();						
						
					}
					prevE = e;
				}
			}
			}

			private void pbUserView_MouseMove(object sender, MouseEventArgs e)
			{
				DefaultMouseMoveEvent(e);
			}
			int index =  0, len;
		
			public void nextdress()
			{
				if ( dress != null )
				{
					len = files.Length;

					if ( len > 0 )
					{
						if ( index == len )
						{
							index = 0;
						}
						LoadDetails();
						dress.ChangeImage(files[index++]); 
					}
				}
			}


			public void prevdress()
			{
				if ( dress != null )
				{
					len = files.Length;

					if ( len > 0 )
					{
						index--;

						if ( index < 0 )
						{
							index = len - 1;
						}
						LoadDetails();
						dress.ChangeImage(files[index]); 
					}
				}
			}
			//
			//		frmWrapNcompare wnc = null;
			//		public void ShowWrapNcompare()
			//		{
			//			if ( wnc == null )
			//			{
			//				wnc = new frmWrapNcompare();
			//				wnc.ShowDialog(this);
			//			}
			//		}
			//		public void CloseWrapNcompare()
			//		{
			//			if ( wnc != null )
			//			{
			//				wnc.closeall();
			//				wnc.Close();
			//				wnc.Dispose();
			//				wnc = null;
			//				this.Focus();
			//				this.BringToFront();
			//			}
			//		}		
		
			public void DefaultDoubleClickEvent()
			{
				//this.parentForm.showWrapNcompare();
				//ShowWrapNcompare();
			}
		
			public void LoadDetails()
			{
				string []strs = null;
				Image img = null;
				if ( dress != null )
				{
					strs = Dress.GetDetailedPictures(files[index]);
					if ( strs != null && strs.Length > 0 )
					{
						if ( this.pbDetailsRight.Image != null )
						{
							this.pbDetailsRight.Image.Dispose();
							this.pbDetailsRight.Image = null;
						}
						img = Image.FromFile(strs[0], true);
					
						this.pbDetailsRight.Image = img;
						//this.pbDetailsLeft.Image = Dress.DrawReflection((Image)img.Clone(), Color.Transparent);
					}
				}
			}

			private void btnNextDress_Click(object sender, System.EventArgs e)
			{
				if ( dress != null )
					nextdress();
			}

			private void btnPrevDress_Click(object sender, System.EventArgs e)
			{
				if ( dress != null )
					prevdress();
			}

			private void timer_Animation_Tick(object sender, System.EventArgs e)
			{
				nextdress();
			}

			private void btnAnim_Click(object sender, System.EventArgs e)
			{
				if ( timer_Animation.Enabled )
				{
					timer_Animation.Enabled = false;
				}
				else
					timer_Animation.Enabled = true;
			}

			public void DefaultKeyAction(KeyEventArgs e)
			{
				if ( e.KeyCode == Keys.F10 )
				{
					Application.Exit();
				}
				else if ( e.KeyCode == Keys.F2 )
				{
					
				}
				else if ( e.KeyCode == Keys.F5 )
				{
					this.stopCapture();
				}
				else if ( e.KeyCode == Keys.PageDown )
				{
					if ( dress != null )
						prevdress();
				}
				else if ( e.KeyCode == Keys.PageUp )
				{
					if ( dress != null )
						nextdress();
				}
				else if ( e.KeyCode == Keys.F7 )
				{
				}
				else if ( e.KeyCode == Keys.F8 )
				{
					this.parentForm.showWrapNcompare();
				}
				else if ( e.KeyCode == Keys.F9 )
				{
					this.parentForm.showDressDetails();
				}
				else if ( e.KeyCode == Keys.P && e.Control == true )
				{
					this.SaveImage();
				}

			}

			public void DefaultMouseDown(MouseEventArgs e)
			{
				/*if ( e.Button == MouseButtons.Left )
				{
					if ( dress != null )
					{
						dress.reduceWidth(chunkSize, false);
						dress.reduceHeight(chunkSize, false);
					}
				}
				else if ( e.Button == MouseButtons.Right )
				{
					if ( dress != null )
					{
						dress.increaseWidth(chunkSize, false);
						dress.increaseHeight(chunkSize, false);
					}
				}*/
			}
			private void frmQuickView_KeyDown(object sender, KeyEventArgs e)
			{
				DefaultKeyAction(e);
			}

			private void frmQuickView_MouseMove(object sender, MouseEventArgs e)
			{
				DefaultMouseMoveEvent(e);
			}

			private void frmQuickView_MouseDown(object sender, MouseEventArgs e)
			{
				DefaultMouseDown(e);
			}

			private void pbUserView_MouseDown(object sender, MouseEventArgs e)
			{
				DefaultMouseDown(e);
			}

			private void pbDetailsRight_MouseMove(object sender, MouseEventArgs e)
			{
				DefaultMouseMoveEvent(e);
			}

			private void pbDetailsRight_MouseDown(object sender, MouseEventArgs e)
			{
				DefaultMouseDown(e);
			}

			private void pbUserView_DoubleClick(object sender, EventArgs e)
			{
				DefaultDoubleClickEvent();
			}

			private void pbDetailsRight_DoubleClick(object sender, EventArgs e)
			{
				DefaultDoubleClickEvent();
			}

			private void frmQuickView_DoubleClick(object sender, EventArgs e)
			{
				DefaultDoubleClickEvent();
			}

			private void SaveImage()
			{

				/*saveFileDialog1.DefaultExt = "bmp";
				saveFileDialog1.Filter = "bmp files (*.bmp)|*.bmp";
				saveFileDialog1.Title = "Save screenshot to...";
				saveFileDialog1.ShowDialog(); */
				string ScreenPath = temp_folder + file_seperator + DateTime.Now.Ticks + ext_bmp; 

				if ("" != ScreenPath)
				{

					Bitmap img = CaptureScreen.GetDesktopImage();
					if ( img != null )
					{
						img.Save(ScreenPath);
						MessageBox.Show("Done");
					}
					//Rectangle bounds = Screen.GetBounds(Screen.GetBounds(Point.Empty));
					//ScreenShot.CaptureImage(Point.Empty, Point.Empty, bounds, ScreenPath);
				}
			}
		}
}
