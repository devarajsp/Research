using System;
using System.IO;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Vastra
{
	/// <summary>
	/// Summary description for frmBody.
	/// </summary>
	public class frmBody : System.Windows.Forms.Form
	{
		private System.Windows.Forms.PictureBox pbBody;
		string img_path;
		private frmQuickView parentForm;
		private frmBody pendent = null;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmBody(frmQuickView frm)
		{
			parentForm = frm;
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		#region PENDENT Related functions
		public void AddPendent(frmBody pendt)
		{
			if ( pendt != null )
			{
				this.pendent = pendt;
			}
		}

		string fixfile_path = null, fixfile_name = "/fair/fix.txt";
		int pend_left, pend_top;
		const int pendentCenter = 50; // fixed and hardcoded
		public string GetFixFilePath()
		{
			string temp = null;
			int l = 0, li = 0;
			
			if ( this.img_path != null )
			{
//				l = this.img_path.Length;
//				li = this.img_path.LastIndexOf("/");
//				temp = this.img_path.Substring(li+1);
//				if ( temp == null || li == l )
//				{
//					li = this.img_path.LastIndexOf("\\");
//					temp = this.img_path.Substring(li+1);
//				}

				temp = img_path + fixfile_name;
			}

			return temp;
		}

        public bool GetPendentLeftAndTop()
		{
			int  mi = 0;
			bool retValue = true;
			string fix_file = null, st = null, lstr, tstr;

			TextReader tr = null;

			fix_file = this.GetFixFilePath();
			if ( fix_file != null && File.Exists(fix_file) )
			{
				tr = File.OpenText(fix_file);
				if ( tr != null )
				{
					st = tr.ReadLine();
					if ( st != null )
					{
						mi = st.LastIndexOf(",");
						lstr = st.Substring(mi+1);
						lstr = lstr.Trim();
						pend_top = Convert.ToInt32(lstr);

						tstr = st.Substring(0, mi);
						tstr = tstr.Trim();
						pend_left = Convert.ToInt32(tstr);
					}
					else
						retValue = false;
					
				}
				else
					retValue = false;
			}
			else
			{
				retValue = false;
			}

			return retValue;
		}

		public bool FixPendentPosition()
		{
			bool retValue = true;
			if ( pendent != null )
			{
				if ( GetPendentLeftAndTop() )
				{
					this.pendent.Visible = true;
					this.pendent.Left = (pend_left + this.Left) - pendentCenter;
					this.pendent.Top  = pend_top + this.Top;
//					MessageBox.Show(" this.pendent.Left "+this.pendent.Left+"\n" +"this.pendent.Top"+this.pendent.Top+"\n" +
//						" pend_left "+ pend_left+"\n" +"pend_top"+pend_top+"\n"+
//										" this.Left "+this.Left+"\n" +"this.Top"+this.Top+"\n");
				}
				else
				{
					this.pendent.Visible = false;
					retValue = false;
				}
			}
			else
			{
				retValue = false;
			}
			return retValue;
		}

		public bool MovePendentPosition()
		{
			bool retValue = true;
			if ( pendent != null )
			{
				//if ( GetPendentLeftAndTop() )
				{
					this.pendent.Left = (pend_left + this.Left) - pendentCenter;
					this.pendent.Top  = pend_top + this.Top;
					//					MessageBox.Show(" this.pendent.Left "+this.pendent.Left+"\n" +"this.pendent.Top"+this.pendent.Top+"\n" +
					//						" pend_left "+ pend_left+"\n" +"pend_top"+pend_top+"\n"+
					//										" this.Left "+this.Left+"\n" +"this.Top"+this.Top+"\n");
				}
//				else
//				{
//					retValue = false;
//				}
			}
			else
			{
				retValue = false;
			}
			return retValue;
		}

		#endregion

		#region FOR Color change option

		public void ChangeColor()
		{
			string fname = Dress.GetNextColorDress(img_path, Dress.SKINTONE_FAIR, Dress.SIZE_HEIGHT_MEDIUM);
			Image img = null;

			if ( fname != null )
				img	= Image.FromFile(fname, true);
			
			if ( this.pbBody.Image != null )
			{
				this.pbBody.Image.Dispose();
				this.pbBody.Image = null;
			}
			this.Width = img.Size.Width;
			this.Height = img.Size.Height;

			this.pbBody.Image = img;

			FixPendentPosition(); //added for pendent

		}
		#endregion

		/*public frmBody()
		{
			InitializeComponent();
		}*/

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.pbBody = new System.Windows.Forms.PictureBox();
			this.SuspendLayout();
			// 
			// pbBody
			// 
			this.pbBody.BackColor = System.Drawing.Color.Transparent;
			this.pbBody.Dock = System.Windows.Forms.DockStyle.Fill;
			this.pbBody.Location = new System.Drawing.Point(0, 0);
			this.pbBody.Name = "pbBody";
			this.pbBody.Size = new System.Drawing.Size(292, 273);
			this.pbBody.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pbBody.TabIndex = 0;
			this.pbBody.TabStop = false;
			this.pbBody.Click += new System.EventHandler(this.pbBody_Click);
			// 
			// frmBody
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.BackColor = System.Drawing.Color.Blue;
			this.ClientSize = new System.Drawing.Size(292, 273);
			this.ControlBox = false;
			this.Controls.Add(this.pbBody);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "frmBody";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
			this.TopMost = true;
			this.TransparencyKey = System.Drawing.Color.Blue;
			this.Load += new System.EventHandler(this.frmBody_Load);
			this.ResumeLayout(false);

		}
		#endregion

		private void frmBody_Load(object sender, System.EventArgs e)
		{
			init();
		}
		public void init()
		{
			this.pbBody.MouseMove +=new MouseEventHandler(pbBody_MouseMove);
			this.MouseMove +=new MouseEventHandler(frmBody_MouseMove);
			this.pbBody.MouseUp +=new MouseEventHandler(pbBody_MouseUp);
			this.KeyDown +=new KeyEventHandler(frmBody_KeyDown);
			this.pbBody.MouseDown +=new MouseEventHandler(pbBody_MouseDown);
		}

		int hLimit_low = Screen.PrimaryScreen.Bounds.Height / 4;
		int wLimit_low = Screen.PrimaryScreen.Bounds.Width / 3 / 4;

		int hLimit_high = Screen.PrimaryScreen.Bounds.Height;
		int wLimit_high = Screen.PrimaryScreen.Bounds.Width / 3;

		public void reduceHeight(int count, bool adjustLocation)
		{
			int expH = this.Height - count;
			if ( count > 0 )//&& expH < hLimit_high && expH > hLimit_low )
			{
				this.Height -= count;
				if ( adjustLocation == true )
				{
					this.Top += count;
				}
			}
		}

		public void increaseHeight(int count, bool adjustLocation)
		{
			int expH = this.Height + count;
			if ( count > 0 )//&& expH < hLimit_high && expH > hLimit_low )
			{
				this.Height += count;
				if ( adjustLocation == true )
				{
					this.Top -= count;
				}
			}
		}

		public void reduceWidth(int count, bool adjustLocation)
		{
			int expW = this.Width - count;
			if ( count > 0 )//&& expW < wLimit_high && expW > wLimit_low )
			{
				this.Width -= count;
				if ( adjustLocation == true )
				{
					this.Left += count;
				}
			}
		}

		public void increaseWidth(int count, bool adjustLocation)
		{
			int expW = this.Width + count;
			if ( count > 0 )//&& expW < wLimit_high && expW > wLimit_low )
			{
				this.Width += count;
				if ( adjustLocation == true )
				{
					this.Left -= count;
				}
			}
		}


		public void LoadImage(string path, int top, int pos)
		{			

			img_path	= path;
			path		= Dress.GetDress(path , Dress.SKINTONE_FAIR, Dress.SIZE_HEIGHT_MEDIUM);
			Image img	= Image.FromFile(path, true);

			
			this.Width	= img.Size.Width;
			this.Height = img.Size.Height;
			//this.Width = 300;
			//this.Height = 600;
			//this.Top = top;

			if ( this.pbBody.Image != null )
			{
				this.pbBody.Image.Dispose();
				this.pbBody.Image = null;
			}
			if ( pos == 1 )
				this.Left	= 0;
			if ( pos == 2 )
				this.Left	= ( Screen.PrimaryScreen.Bounds.Width - this.Width ) / 2;
			if ( pos == 3 )
				this.Left	= Screen.PrimaryScreen.Bounds.Width - this.Width;
			if ( pos > 3 )
				this.Left	= pos;


			this.pbBody.Image = img;
			//this.pbBody.Image = FaceDetection.RemoveBorder(img);
			

			FixPendentPosition(); //added for pendent

			//img.Dispose();
			img = null;
			GC.Collect();

		}


		public void ChangeImage(string path)
		{
			string fname = Dress.GetDress(path, Dress.SKINTONE_FAIR, Dress.SIZE_HEIGHT_MEDIUM);
			Image img = null;
			img_path	= path;

			if ( fname != null )
				img	= Image.FromFile(fname, true);
			
			if ( this.pbBody.Image != null )
			{
				this.pbBody.Image.Dispose();
				this.pbBody.Image = null;
			}
			this.Width = img.Size.Width;
			this.Height = img.Size.Height;

			this.pbBody.Image = img;

			FixPendentPosition(); //added for pendent
		}

		public void ChangeImage(string path, int h, int w)
		{
			string fname = Dress.GetDress(path, Dress.SKINTONE_FAIR, Dress.SIZE_HEIGHT_MEDIUM);
			Image img = null;
			img_path	= path;

			if ( fname != null )
				img	= Image.FromFile(fname, true);
			
			if ( this.pbBody.Image != null )
			{
				this.pbBody.Image.Dispose();
				this.pbBody.Image = null;
			}
			this.Width = w;
			this.Height = h;

			this.pbBody.Image = img;

			FixPendentPosition(); //added for pendent
		}


		private void pbBody_Click(object sender, System.EventArgs e)
		{
		
		}

		//MouseEventArgs prevE = null;
		private void pbBody_MouseMove(object sender, MouseEventArgs e)
		{
			/*if ( e.Button == MouseButtons.Left ) 
			{
				if ( prevE == null )
					prevE = e;
				else
				{
					this.Top += ( e.Y - prevE.Y);
					this.Left += (e.X - prevE.X);
				}
			}*/
			if ( this.parentForm != null )
			{
				this.parentForm.PlaceCursorInDefaultPosition();
			//	this.parentForm.DefaultMouseMoveEvent(e);
			}
		}

		private void pbBody_MouseUp(object sender, MouseEventArgs e)
		{
			//prevE = null;
		}

		private void frmBody_KeyDown(object sender, KeyEventArgs e)
		{
			if ( parentForm != null )
			{
				parentForm.DefaultKeyAction(e);
			}
		}

		private void pbBody_MouseDown(object sender, MouseEventArgs e)
		{
			
			if ( parentForm != null )
			{
				parentForm.DefaultMouseDown(e);
			}
		}

		private void frmBody_MouseMove(object sender, MouseEventArgs e)
		{
			pbBody_MouseMove(sender,e);
		}

		public void ReduceSizeOfImage()
		{
			int h = this.Height;
			int w = this.Width;
			string fname = Dress.GetDress(this.parentForm.files[this.parentForm.index], Dress.SKINTONE_FAIR, Dress.SIZE_HEIGHT_MEDIUM);
			w -= 10;
			h -= 10;
			ChangeImage(this.parentForm.files[this.parentForm.index], h, w);
		}
		
		public void IncreaseSizeOfImage()
		{
			int h = this.Height;
			int w = this.Width;
			string fname = Dress.GetDress(this.parentForm.files[this.parentForm.index], Dress.SKINTONE_FAIR, Dress.SIZE_HEIGHT_MEDIUM);
			w += 10;
			h += 10;
			ChangeImage(this.parentForm.files[this.parentForm.index], h, w);
		}
	
	}
}
