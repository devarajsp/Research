using System;
using System.IO;
using System.Drawing; 
using System.Drawing.Drawing2D; 
using System.Drawing.Imaging;

namespace Vastra
{
	/// <summary>
	/// Summary description for Dress.
	/// </summary>
	public class Dress
	{
		public const string SKINTONE_DARK			= "dark";
		public const string SKINTONE_MEDIUMDARK		= "medium";
		public const string SKINTONE_FAIR			= "fair";
		public const string SKINTONE_VERYFAIR		= "veryfair";

		public const string SIZE_HEIGHT_SMALL		= "height_small";
		public const string SIZE_SHORT_SMALL		= "short_small";
		public const string SIZE_HEIGHT_MEDIUM		= "height_medium";
		public const string SIZE_SHORT_MEDIUM		= "short_medium";
		public const string SIZE_HEIGHT_XL			= "height_xl";
		public const string SIZE_SHORT_XL			= "short_xl";
		public const string SIZE_HEIGHT_XXL			= "height_xxl";
		public const string SIZE_SHORT_XXL			= "short_xxl";

		public static Image DrawReflection(Image img,Color toBG) // img is the original image.
		{
			//This is the static function that generates the reflection...
			int height = img.Height + 100; //Added height from the original height of the image.
			Bitmap bmp = new Bitmap(img.Width, height, PixelFormat.Format64bppPArgb); //A new 
			//bitmap.
			//The Brush that generates the fading effect to a specific color of your background.
			Brush brsh = new LinearGradientBrush(new Rectangle(0, 0, img.Width + 10, 
				height), Color.Transparent, toBG, LinearGradientMode.Vertical);
			bmp.SetResolution(img.HorizontalResolution, img.VerticalResolution); //Sets the new 
			//bitmap's resolution.
			using(Graphics grfx = Graphics.FromImage(bmp)) //A graphics to be generated 
			//from an image (here, the new Bitmap we've created (BMP)).
			{
				Bitmap bm = (Bitmap)img; //Generates a bitmap from the original image (img).
				grfx.DrawImage(bm, 0, 0, img.Width, img.Height); //Draws the generated 
				//bitmap (bm) to the new bitmap (bmp).
				Bitmap bm1 = (Bitmap)img; 	//Generates a bitmap again 
				//from the original image (img).
				bm1.RotateFlip(RotateFlipType.Rotate180FlipX); //Flips and rotates the 
				
				//image (bm1).
				grfx.DrawImage(bm1, 0, img.Height); 	//Draws (bm1) below (bm) so it serves 
				//as the reflection image.
				Rectangle rt = new Rectangle(0, img.Height, img.Width, 100); //A new rectangle 
				//to paint our gradient effect.
				grfx.FillRectangle(brsh, rt); //Brushes the gradient on (rt).
			}
			return bmp; //Returns the (bmp) with the generated image.
		}


		public Dress()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public const string FILE_SEP			= "/";
		public const string THUMBNAIL_FILE1		= "thumb1.gif";
		public const string THUMBNAIL_FILE2		= "thumb2.gif";
		public const string DRESS_FILE			= "dress_";
		public const string EXT_GIF				= ".gif";  //SPD BGFIX
		//public const string EXT_GIF				= ".png";
		public const string EXT_PNG				= ".png";
		public const string DETAILS_FOLDER		= "details";
		public const string PATTERN_ALL_GIF_FILES = "*.gif"; //SPD BGFIX
		public const string PATTERN_ALL_JPG_FILES = "*.jpg"; 
		//public const string PATTERN_ALL_GIF_FILES = "*.png";
		public const string PATTERN_ALL_PNG_FILES = "*.png";
		public const string FIX_FILE			   = "fix.txt";

		public static string GetThumbnail1(string dressFolder)
		{
			string tfile = dressFolder + FILE_SEP + THUMBNAIL_FILE1;
			return ReturnFileName(dressFolder, tfile);
		}

		public static string GetThumbnail2(string dressFolder)
		{
			string tfile = dressFolder + FILE_SEP + THUMBNAIL_FILE2;
			return ReturnFileName(dressFolder, tfile);
		}
		public static string GetDress(string dressFolder, string skinTone, string size)
		{
			string tfolder	= dressFolder + FILE_SEP + skinTone + FILE_SEP;
			string tfile	= tfolder + DRESS_FILE + size + EXT_GIF;

			//string tfile	= tfolder + DRESS_FILE + EXT_GIF;
			tfile = ReturnFileName(tfolder, tfile);
			if ( tfile == null )
			{
				tfile = tfolder + DRESS_FILE + EXT_GIF;
				tfile = ReturnFileName(tfolder, tfile);
			}
			return tfile;
		}

		static int ctr = 0;
		public static string GetNextColorDress(string dressFolder, string skinTone, string size)
		{
			
			string tfolder	= dressFolder + FILE_SEP + skinTone + FILE_SEP;

			string []allfiles = Directory.GetFiles(tfolder,PATTERN_ALL_GIF_FILES);
			string tfile = "";
			if ( ctr >= allfiles.Length )
			{
				ctr = 0;
			}

			if ( allfiles.Length > 0 && ctr < allfiles.Length )
			{
				tfile = allfiles[ctr];
				ctr++;
			}
		
			//string tfile	= tfolder + DRESS_FILE + EXT_GIF;
			tfile = ReturnFileName(tfolder, tfile);
			return tfile;
		}

		public static string GetFixFile(string dressFolder, string skinTone)
		{
			string tfolder	= dressFolder + FILE_SEP + skinTone + FILE_SEP;
			string tfile	= tfolder + FIX_FILE;

			tfile = ReturnFileName(tfolder, tfile);
			
			return tfile;		
		}

		public static string [] GetDetailedPictures(string dressFolder)
		{
			string []tfiles = null;
			string tfolder = dressFolder + FILE_SEP + DETAILS_FOLDER;
			if ( Directory.Exists(tfolder) )
			{
				tfiles = Directory.GetFiles(tfolder, PATTERN_ALL_JPG_FILES);
			}
			return tfiles;
		}

		private static string ReturnFileName(string fol, string file)
		{
			if ( Directory.Exists(fol) )
				if ( File.Exists(file) )
					return file;
			
			return null;		
		}
	}
}
